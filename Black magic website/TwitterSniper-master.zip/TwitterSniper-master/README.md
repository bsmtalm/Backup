# TwitterSniper
<center>
<h3>Brute Force Attack On Twitter Script</h3>
<br/>
<img src="https://s24.postimg.org/6jfo58a3p/Screenshot_from_2017_01_29_20_1.png" />
<br/>
<h3>
you need to install mechanicalsoup
<br/>
</h3>
pip3 install mechanicalsoup
</center>
